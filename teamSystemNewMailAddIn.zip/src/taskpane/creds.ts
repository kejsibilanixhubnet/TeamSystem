export const creds = {
  client_id: "Ha5JbQpl8vkegClLw",
  client_secret: "CsFj4KFbPopxCUxk4WCPZOe6RBzgc4Qc1TMWJ5nTe7zs3QhPgE3x0k5xaUVwM2D6L",
};
